(function($) {
    'use strict';

    $(function() {
    	$('#tip').removeClass('hidden');
    });

})(jQuery);
