while x < 10 do
  if a == 1 then
    print(1)
  end
  if b == 1 then
    break
  end
  if c == 1 then
    print(1)
  else
    break
  end
  if a == 2 then
    print(2)
  end
  if b == 2 then
    break
  end
  if c == 2 then
    print(2)
  else
    break
  end
end
