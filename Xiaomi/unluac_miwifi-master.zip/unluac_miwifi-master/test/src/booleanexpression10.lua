print((x or {}).__tostring)
