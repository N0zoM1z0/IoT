local a
for b = 1, 10 do
  for c = 1, 10 do
    if a then break end
    break
  end
  break
end
