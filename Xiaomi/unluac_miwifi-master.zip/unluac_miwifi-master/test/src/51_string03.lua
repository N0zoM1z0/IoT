print[==[
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
(yes, very long)
disallow this kind of pipe: ]]
now, make the end fail to match the next pipe without actually
containing it in the string]=]==]

print[=[
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
lots of garbage to start so that unluac will attempt to decompile as long string
(yes, very long)
same test but for the basic pipe end: ]]=]