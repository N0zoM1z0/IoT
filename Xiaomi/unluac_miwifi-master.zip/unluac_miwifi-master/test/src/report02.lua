function report02(a, b)
  if a == 1 then
    if f(b) > 0 then
      -- do nothing
    end
  else
    return
  end
end