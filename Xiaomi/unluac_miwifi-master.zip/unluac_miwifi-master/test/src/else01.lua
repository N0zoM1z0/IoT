if z == nil and w == nil then
  if x == y then
    result = true
  elseif x == z then
    print(z)
    if n then
      print(n)
    end
  else
    error()
  end
else
  error()
end
