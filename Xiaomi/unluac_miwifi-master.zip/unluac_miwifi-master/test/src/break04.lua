local a, b = 5, 5
while a < b do
  print("a")
  a, b = a / b * j, fmod(a, b) * k
  if b > j then
    print("b")
    if x == nil then
      break
    end
  end
end
