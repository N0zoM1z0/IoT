local x = a and (f() or c==0)
print(x)
