function f()
  a,b,c = g(),g(),g()
end
