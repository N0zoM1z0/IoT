if check() then
  do1()
else
end