while 1 do
  print("x")
  work()
end
