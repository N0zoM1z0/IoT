local x = f()
if x < 5 then
  f()
end
if x < 5.0 then
  f()
end
if x < -5 then
  f()
end
if x < -5.0 then
  f()
end
if x > 5 then
  f()
end
if x > 5.0 then
  f()
end
if x > -5 then
  f()
end
if x > -5.0 then
  f()
end
if x <= 5 then
  f()
end
if x <= 5.0 then
  f()
end
if x <= -5 then
  f()
end
if x <= -5.0 then
  f()
end
if x >= 5 then
  f()
end
if x >= 5.0 then
  f()
end
if x >= -5 then
  f()
end
if x >= -5.0 then
  f()
end
if x == 5 then
  f()
end
if x == 5.0 then
  f()
end
if x == -5 then
  f()
end
if x == -5.0 then
  f()
end
if x == "5" then
  f()
end

if 5 < x then
  f()
end
if 5.0 < x then
  f()
end
if -5 < x then
  f()
end
if -5.0 < x then
  f()
end
if 5 > x then
  f()
end
if 5.0 > x then
  f()
end
if -5 > x then
  f()
end
if -5.0 > x then
  f()
end
if 5 <= x then
  f()
end
if 5.0 <= x then
  f()
end
if -5 <= x then
  f()
end
if -5.0 <= x then
  f()
end
if 5 >= x then
  f()
end
if 5.0 >= x then
  f()
end
if -5 >= x then
  f()
end
if -5.0 >= x then
  f()
end
if 5 == x then
  f()
end
if 5.0 == x then
  f()
end
if -5 == x then
  f()
end
if -5.0 == x then
  f()
end
if "5" == x then
  f()
end
