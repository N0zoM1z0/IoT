local a, b = t[1], t[2] or {}
