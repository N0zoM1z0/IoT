function a()
  repeat
    x = true
  until z == 0
end
function b()
  repeat
    x = true
  until z < 0
end
function c()
  repeat
    x = true
  until z <= 0
end
