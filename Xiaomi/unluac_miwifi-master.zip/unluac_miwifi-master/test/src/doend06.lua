while true do
  local v, w = 0
  print(w, v)
end
