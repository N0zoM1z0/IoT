function f(x)
  g, h = x
  i, j = x, nil
end
