if a then
  if {} then
    print("x")
  end
end