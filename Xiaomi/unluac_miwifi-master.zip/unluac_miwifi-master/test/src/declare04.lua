local upvalue
function f()
  local a, b
  upvalue = nil
end
