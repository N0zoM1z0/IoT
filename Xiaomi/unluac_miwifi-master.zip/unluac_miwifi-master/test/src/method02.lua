local x,y
;(x+y):print()
;("aeiou"):gsub(".",print)
print((arg).x)
x = (x+y).z
y = ("asdf").gsub
;(-x):print()
print()
;("aeiou").n = x
;({x=print}).x("hi")