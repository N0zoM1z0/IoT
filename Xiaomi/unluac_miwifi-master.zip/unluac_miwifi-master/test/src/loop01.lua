while true do
  print('first')
  if test then
    print('second')
  else
    print 'third'
  end
end
