local x = x or a == b
x = true

local y = x or a ~= b
y = true

local z = a == b or c == d
z = true
