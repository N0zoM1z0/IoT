local a, b, c, d, e, g

a = g or a
b = g or b
if e then
  d = g or d
  e = g or e
end
