do
  local a = 512
  print(a)
end
do
  local b = 255
  print(b)
end