local x = f()
g = x or nil
