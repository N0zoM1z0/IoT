local a, b

a = (-1) ^ b
a = (-0.0) ^ b
a = 2 ^ b
