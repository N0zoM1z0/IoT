local a
a = x + y + z
a = x + (y + z)
a = x + y - z
a = x - y + z
a = x - y - z
a = x - (y - z)
a = x * y * z
a = x * (y * z)
a = x + y * z
a = (z + y) / z
a = x / (y + z)
a = x ^ y ^ z
a = (x ^ y) ^ z
a = x .. y .. z
a = (x .. y) .. z
