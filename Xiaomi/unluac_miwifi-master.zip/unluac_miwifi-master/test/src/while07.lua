local x
while test() do
  x = a or b + 1
end
