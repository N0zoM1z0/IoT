for x = 1, 10 do
  repeat
    print("before")
    do break end
    print("after")
  until true
end