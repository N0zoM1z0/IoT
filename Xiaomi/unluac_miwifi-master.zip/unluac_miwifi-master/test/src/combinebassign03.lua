local t, x
if a then
  x = t[1] == "ref" and t[2]
else
  print("else")
end
