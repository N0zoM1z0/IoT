local a = x == 0 or {1, 2, 3}
local b = x == 1 or {a = 1, b = 3, c = 3}
print(a, b)
