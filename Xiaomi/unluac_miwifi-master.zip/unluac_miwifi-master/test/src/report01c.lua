function myfunction(value)
	value = x or value
end