if a then
  print("separate")
  if x == y then
    -- empty
  end
end
