function func()
  local x = f()
  if test(x) then
  end
end