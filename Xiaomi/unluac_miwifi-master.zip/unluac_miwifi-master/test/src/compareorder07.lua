if 1 == 1.0 then
  f()
end
if 2.0 == 2 then
  f()
end
if 3 < 3.0 then
  f()
end
if 4.0 < 4 then
  f()
end
if 5 > 5.0 then
  f()
end
if 6.0 > 6 then
  f()
end
if 7 <= 7.0 then
  f()
end
if 8.0 <= 8 then
  f()
end
if 9 >= 9.0 then
  f()
end
if 10.0 >= 10 then
  f()
end
if 11 ~= 11.0 then
  f()
end
if 12.0 ~= 12 then
  f()
end
if "13" == 13 then
  f()
end
if 14 == "14" then
  f()
end
if "15" == 15.0 then
  f()
end
if 16.0 == "16" then
  f()
end
if "17" ~= 17 then
  f()
end
if 18 ~= "18" then
  f()
end
if "19" ~= 19.0 then
  f()
end
if 20.0 ~= "20" then
  f()
end
