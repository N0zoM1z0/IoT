if x then
  print("x")
else
  repeat
    print("else")
  until test()
end
print("end")
