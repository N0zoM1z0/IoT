if x then
  print("guard")
  if y then
    if z then
      print("z")
    else
      print("not z")
    end
  end
elseif a then
  print("a")
end
