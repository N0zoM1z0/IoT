local result = a < b and not c
print(result)