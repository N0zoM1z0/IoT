local a
local b
local c, d
local e
if x ~= a and not t[e] then
  local f = ((d == x) and c or x) - 1
  print("more")
end
