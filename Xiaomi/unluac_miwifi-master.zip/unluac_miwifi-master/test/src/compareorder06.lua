if f1() == "a" then
  g()
end
if "b" == f2() then
  g()
end
if f3() ~= "c" then
  g()
end
if "d" ~= f4() then
  g()
end
