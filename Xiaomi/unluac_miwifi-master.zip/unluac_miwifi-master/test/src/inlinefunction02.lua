-- yes, this doesn't work, but it is syntactically valid
(function(self, s) print(s) end):p("hello")
