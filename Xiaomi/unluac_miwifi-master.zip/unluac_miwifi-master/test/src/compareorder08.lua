if left1("common1") == "common1" then
  f()
end
if "common2" == right2("common2") then
  f()
end
if left3("common3") < "common3" then
  f()
end
if "common4" > right4("common4") then
  f()
end
if "left5" == "right5" then
  f()
end
