local x
if not x then
  guard()
  x = g < 3
end
