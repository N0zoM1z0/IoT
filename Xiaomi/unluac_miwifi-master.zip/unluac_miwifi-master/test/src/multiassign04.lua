local a, b, c = f()
b, c = "", nil
