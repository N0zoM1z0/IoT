local x
if a then
  if not x then
     x = f()
  end
end
