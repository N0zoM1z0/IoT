if buffer then
  print("hello")
end
local multi1a, multi1b, multi1c = 1, 2, 3
local multi2a, multi2b, multi2c = multi_return()
local multi3a, multi3b, multi3c = multi_return(x, y, z)
