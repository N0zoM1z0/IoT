if a then
  while b do
    f()
  end
end
