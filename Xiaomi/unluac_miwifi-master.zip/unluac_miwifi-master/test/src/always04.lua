function test1()
  repeat
    repeat
      break
    until true
  until false
end

function test2()
  while true do
    repeat
      break
    until true
  end
end
