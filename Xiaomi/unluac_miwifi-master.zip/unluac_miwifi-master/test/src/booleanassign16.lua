local a, b = f()
local c = not a and 1 or b + 1
print(c)
