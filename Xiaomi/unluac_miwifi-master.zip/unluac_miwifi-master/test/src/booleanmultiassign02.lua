local q
local n, t = f(), q or s[1]
print(n, t)
