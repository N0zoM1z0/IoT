t["goto"] = function(x, y)
  if x then y() end
end
