function myfunction(value)
	value = value==nil and true or value
end