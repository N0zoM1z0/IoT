print("nested long string [[support in Lua 5.1 [[ is ]] controlled by ]] LUA_COMPAT_LSTR\nnewlines\nare\nneeded\nto\ntrip\nthe\nunluac\nlong string\nheuristic")
