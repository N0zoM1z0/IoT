("string"):method();
("string")();
(1234):method();
(1234)();
(nil):method();
(nil)();
(true):method();
(true)();
