if a and b or c(x == y or a or 5) and z then
  print("hello")
end
