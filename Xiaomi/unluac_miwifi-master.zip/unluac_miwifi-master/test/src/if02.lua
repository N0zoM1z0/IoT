if a then
  for _, v in ipairs(mylist) do
    print(v)
  end
  if b then
    print("done")
  end
end
