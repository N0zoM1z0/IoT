function myfunction(value)
	value = true or value
end