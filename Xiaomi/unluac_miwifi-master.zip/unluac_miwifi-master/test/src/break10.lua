local a
while x do
  a = b or c
  -- testset redirected by break
  break
end
