for k, v in pairs(t) do
  if f() and g(a or b) then
    print("yes")
  else
    print("no")
  end
end
