local a
a = 1
a = 1.0
a = -0
a = -0.0
