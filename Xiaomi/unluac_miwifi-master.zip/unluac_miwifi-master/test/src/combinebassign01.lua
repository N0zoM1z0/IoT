local x
x = x == nil or x
print(x)
