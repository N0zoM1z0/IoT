function f(...)
  return arg
end
