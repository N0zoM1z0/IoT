local a, b = "asdf", "qwer"
local val = not (a and b)
print(tostring(val))
