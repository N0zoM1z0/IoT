local x = 0
function f(...)
  x = g() == a or ...
end
