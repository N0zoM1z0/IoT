for k, v in iter() do
  if a then
    if b then
      return
    elseif c then
      print(c)
    elseif d then
      print(d)
    end
  end
  break
end
