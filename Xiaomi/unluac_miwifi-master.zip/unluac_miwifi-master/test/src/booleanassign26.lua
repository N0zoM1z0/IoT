local x = f()
x = not x and 0 or t[x] or x
