local t, u, i = f()
local x, y = t[i] or 1, u[i] or 2
print(x, y)
