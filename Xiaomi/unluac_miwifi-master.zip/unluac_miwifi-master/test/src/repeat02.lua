if test then
  repeat
    -- nothing
  until attempt() == test
end
