local a
a = b or c == d or e
