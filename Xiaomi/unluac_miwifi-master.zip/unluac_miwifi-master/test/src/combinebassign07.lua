local a, b, c, d, e, f
a = b == 0 and c or (d + e) * f
