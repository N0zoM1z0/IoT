function myfunction(value)
	value = true or 3
end