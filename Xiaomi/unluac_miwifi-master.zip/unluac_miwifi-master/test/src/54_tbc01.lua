(function()
  local x <close> = 5
  print(x)
end)()
(function()
  local x <close>, y = 5, 6
  print(x)
end)()
(function()
  local y, x <close> = 5, 6
  print(x)
end)()
(function()
  local x <close> = 5
  local y <close> = 6
  print(x)
end)()
