for x in (pairs(t)) do
  print(x)
end