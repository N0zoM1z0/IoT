print(0.0)
print(-0.0)
