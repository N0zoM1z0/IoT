if a then
  print(1)
end
while b do
  print(2)
end
print(3)
