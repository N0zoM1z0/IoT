print(0.0/1.0)
print(-0.0/1.0)
print(0.0/0.0)
