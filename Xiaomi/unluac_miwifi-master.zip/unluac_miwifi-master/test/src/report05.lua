while y do
  y()
  do break end
  while z do
    z()
  end
end
