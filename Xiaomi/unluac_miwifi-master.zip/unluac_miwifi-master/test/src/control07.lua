repeat
  repeat
    f()
  until b
  g()
until a