local a, aa, b, bb = g()

return (a == b) and f(aa, bb) or a or b
