local t = {}
if a then
  t[1] = 0 -- a and b can't be combined
  if b then
    print("middle", t)
  end
end
