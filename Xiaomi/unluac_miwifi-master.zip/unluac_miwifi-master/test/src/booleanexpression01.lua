print(a or b)
print(a and b)
