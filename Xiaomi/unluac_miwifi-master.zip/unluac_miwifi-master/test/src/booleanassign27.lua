local x, y
x, y = x and x < 2 and x or nil, y and y < 3 and y or nil
print(x,y)
