local x
if a then
  print("if")
  if not x then
    x = b
  end
else
  print("else")
end
