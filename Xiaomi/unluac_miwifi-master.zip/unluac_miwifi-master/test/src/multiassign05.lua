local x, y
x, t[1], t.field, t[x], t[x + 4], y = 1, 2, 3, 4, 5, 6
