local x
if t then
  x = y or 3
else
  x = (y == 0)
end
