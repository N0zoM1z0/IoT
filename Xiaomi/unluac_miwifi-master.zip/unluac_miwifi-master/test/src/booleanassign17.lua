local x, y
x = x and f(x,0,y and 1 or 2,"asdf") or 3
