function f()
  _ENV[1] = 0
  return _ENV[1]
end
