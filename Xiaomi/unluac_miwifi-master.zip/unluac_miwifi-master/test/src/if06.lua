if a then
  print("a")
else
  local x
  if b then
    if c then
      -- empty
    else
      print("b,~c")
    end
  end
end
