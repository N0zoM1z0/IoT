local a, b, c, d, e, g
a = f() or a
b = f() or b
if e then
  d = f() or d
  e = f() or e
end
