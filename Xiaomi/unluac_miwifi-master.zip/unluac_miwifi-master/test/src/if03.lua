local t = {}
do_work(t)

if not t.x then
  t.x = f()
end
               