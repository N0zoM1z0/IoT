while a do
  if b then
    f()
  else
    break
  end
end
