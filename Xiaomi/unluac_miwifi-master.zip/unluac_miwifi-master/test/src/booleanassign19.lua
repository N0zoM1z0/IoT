local t, u, v, i = f()
local x, y, z = t[i] or 1, u[i] or 2, v[i] or 3
print(x, y, z)
