local x, y = f()
if not y then
  x, y = a, b
end
print(x, y)
