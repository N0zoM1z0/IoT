if x then
  for i=1,10 do
    if a then
      print("okay")
    elseif b then
      print("b")
      break
    else
      break
    end
  end
else
  print("else")
end
print("done")
