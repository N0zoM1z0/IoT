local a, b, c, d
a, b = b, a
a, b, c, d = b, c, d, a
