package unluac.test;

public enum TestResult {

  OK, SKIPPED, FAILED

}
