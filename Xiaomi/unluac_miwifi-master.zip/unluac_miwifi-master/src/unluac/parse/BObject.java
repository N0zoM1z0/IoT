package unluac.parse;

abstract public class BObject {

}
