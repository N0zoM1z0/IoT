package unluac.assemble;

@SuppressWarnings("serial")
public class AssemblerException extends Exception {
  
  AssemblerException(String msg) {
    super(msg);
  }
  
}
