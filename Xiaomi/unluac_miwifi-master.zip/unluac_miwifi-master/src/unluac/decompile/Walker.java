package unluac.decompile;

import unluac.decompile.expression.Expression;
import unluac.decompile.statement.Statement;

public class Walker {

  public void visitStatement(Statement stmt) {
    
  }
  
  public void visitExpression(Expression expr) {
    
  }
  
}
