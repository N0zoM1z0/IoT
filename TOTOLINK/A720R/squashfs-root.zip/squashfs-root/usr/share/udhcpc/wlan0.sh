#!/bin/sh

exec /usr/share/udhcpc/wlan0.$1
