#!/bin/sh

exec /usr/share/udhcpc/eth1.1.$1
