echo "gpio btn reset!"

jffs2reset -y
reboot


